package com.spring.boot.cart.application.dao;

import com.spring.boot.cart.application.entity.Account;

public interface AccountDAO {
 
    
    public Account findAccount(String userName );
    
}